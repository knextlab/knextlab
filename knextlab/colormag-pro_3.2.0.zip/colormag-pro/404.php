<?php
/**
 * The template for displaying 404 pages (Page Not Found).
 *
 * @package    ThemeGrill
 * @subpackage ColorMag
 * @since      ColorMag 1.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

/**
 * Hook: colormag_before_body_content.
 */
do_action( 'colormag_before_body_content' );
?>

	<?php colormag_two_sidebar_select(); ?>

	<div id="primary">
		<div id="content" class="clearfix">
			<section class="error-404 not-found">
				<div class="page-content">

					<?php if ( ! is_active_sidebar( 'colormag_error_404_page_sidebar' ) ) : ?>
						<header class="page-header">
							<h1 class="page-title"><?php esc_html_e( 'Oops! That page can&rsquo;t be found.', 'colormag' ); ?></h1>
						</header>

						<p><?php esc_html_e( 'It looks like nothing was found at this location. Try the search below.', 'colormag' ); ?></p>
						<?php get_search_form(); ?>

						<div class="error-wrap">
							<span class="num-404">
								<?php esc_html_e( '404', 'colormag' ); ?>
							</span>

							<span class="error"><?php esc_html_e( 'Error', 'colormag' ); ?></span>
						</div>
					<?php
					else :
						dynamic_sidebar( 'colormag_error_404_page_sidebar' );
					endif;
					?>

				</div><!-- .page-content -->
			</section><!-- .error-404 -->
		</div><!-- #content -->
	</div><!-- #primary -->

<?php
colormag_sidebar_select();

/**
 * Hook: colormag_after_body_content.
 */
do_action( 'colormag_after_body_content' );

get_footer();
